# coding=utf-8
# --------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------
from .v2015_05_01.models import *
from .v2017_10_01.models import *
from .v2018_05_01_preview.models import *
from .v2018_06_17_preview.models import *
from .v2019_10_17_preview.models import *
from .v2020_02_02_preview.models import *
from .v2020_03_01_preview.models import *
from .v2020_06_02_preview.models import *
from .v2022_06_15.models import *
